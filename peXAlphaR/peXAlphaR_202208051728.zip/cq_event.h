#ifndef CQ_EVENT_H
#define CQ_EVENT_H

#include <regex>
#include "cq_msg.h"

typedef enum eventTriggerType { TRIG_NEVER = 0, TRIG_ALWAYS = 1, MSG_MATCH = 2, MSG_CONTAIN = 4, MSG_REGEX = 8, TRIG_CUSTOMIZE = 16 };
typedef enum eventType { EVENT_NONE = 0, EVENT_ALL = 1, EVENT_PRIVATE = 2, EVENT_GROUP = 4};
typedef enum messageCodeType { CODE_UNICODE = 0, CODE_UTF8 = 1 };

typedef struct eventTag {
	//event index
	int index;
	//permission level needed to trigger this event.
	int permission;
	//name of event
	std::string name;
	//usage example of event
	std::string example;
	//description of event
	std::string description;
};

class CQEvent {
public:
	//descriptions of event, optional.
	eventTag tag;

	//pointer to function that event will trigger.
	int (*event_func)(CQmsg& msg);
	//Custom trigger condition function.Returning 1 for trig.
	int (*custom_condition)(CQmsg& msg);
	
	//using eventTriggerType
	int trig_type;
	//using eventType
	int event_type;
	//Code type of input CQmsg
	int msg_codetype;

	//default string as unicode
	std::vector<std::string> trig_msg;
	//trigger regex as string, available while trig_type is MSG_REGEX.
	std::string trig_regex;

	CQEvent(int tag_index = 0,\
			int tag_permission = 0,\
			std::string tag_name = "",\
			std::string tag_example = "",\
			std::string tag_description = "",\
			int (*event_function)(CQmsg& msg) = nullptr,\
			int (*condition_function)(CQmsg& msg) = nullptr,\
			int trig_typ = eventTriggerType::TRIG_NEVER,\
			int event_typ = eventType::EVENT_NONE,\
			int msg_codetyp = messageCodeType::CODE_UTF8,\
			std::string trigger_msg = "",\
			std::string trigger_reg = "");

	virtual ~CQEvent();

	//Auto check, ban & unban according to event_type.
	int isBanned(std::string id);
	int ban(std::string id);
	int unban(std::string id);

	//Group
	int isBannedGroup(std::string id);
	int banGroup(std::string id);
	int unbanGroup(std::string id);

	//User
	int isBannedUser(std::string id);
	int banUser(std::string id);
	int unbanUser(std::string id);

	//Check & trigger event
	int trig(CQmsg& msg);

private:
	std::vector<std::string> banned_group;
	std::vector<std::string> banned_user;

	int checkTriggerCondition(CQmsg& msg);
};

template<typename _T>
int searchFromVector(std::vector<_T>& vec, _T key) {
	for (auto iter = vec.begin(); iter != vec.end(); iter++) {
		if (*iter == key) {
			return 1;
		}
	}
	return 0;
}

template <typename _T>
size_t searchIndexFromVector(std::vector<_T>& vec, _T key) {
	size_t sz = vec.size();
	for (size_t i = 0; i < sz; i++) {
		if (vec[i] == key) {
			return i;
		}
	}
	return -1;
}

#endif // !CQ_EVENT