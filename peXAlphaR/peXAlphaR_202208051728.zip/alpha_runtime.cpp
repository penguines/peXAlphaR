#include "alpha_runtime.h"

static std::string GROUP_DATA_FOLDER;
static std::string USER_DATA_FOLDER;
static jsonFile EMPTY_JSON_DATA;

void alpha_runtime::setGroupDataFolder(std::string folder_path){
	GROUP_DATA_FOLDER = folder_path;
}

void alpha_runtime::setUserDataFolder(std::string folder_path){
	USER_DATA_FOLDER = folder_path;
}

void loadCQUserData(CQuser& user, CQUserDataList& user_data){
	for (int i = 0; i < user_data.size(); i++) {
		if (user_data[i].uid == user.u64_id) {
			user.customed_user_data = &(user_data[i]);
			return;
		}
	}
	if (!USER_DATA_FOLDER.empty()) {
		createNewCQUserData(user_data, user.id);
		user.customed_user_data = &(user_data.back());
		return;
	}

#ifdef ALPHA_NO_NULL_JSON
	//��ֹδ�������ݴ洢�ļ��е���pJsonFile_tΪnullptr��������
	user.customed_user_data = &EMPTY_JSON_DATA;
#endif // ALPHA_NO_NULL_JSON
}

void loadCQmsgUserData(CQPrivateMsg& msg, CQUserDataList& user_data){
	loadCQUserData(*(msg.sender), user_data);
}

void loadCQmsgUserData(CQGroupMsg& msg, CQUserDataList& user_data){
	loadCQUserData(*(msg.sender), user_data);
}

void loadCQmsgGroupData(CQGroupMsg& msg, CQGroupList& groups_data, CQGrpMbrDataList& groups_member_data){
	for (int i = 0; i < groups_member_data.size(); i++) {
		if (groups_member_data[i].group_id == msg.group->id) {
			msg.group = &(groups_data[i]);
			jsonFileList& members = groups_member_data[i].members_data;
			for (int j = 0; j < members.size(); j++) {
				if (members[j].uid == msg.sender->u64_id) {
					msg.sender->customed_grpmbr_data = &(members[j]);
					return;
				}
			}
			createNewCQGrpmbrData(groups_member_data[i], msg.sender->id);
			msg.sender->customed_grpmbr_data = &(groups_member_data[i].members_data.back());
			return;
		}
	}
	if (!GROUP_DATA_FOLDER.empty()) {
		if(createNewCQGroupData(groups_data, msg.group->id)){
			msg.group = &(groups_data.back());
			groups_member_data.emplace_back();
			CQGroupMemberData& new_data_tmp = groups_member_data.back();
			new_data_tmp.group_id = msg.group->id;
			createNewCQGrpmbrData(new_data_tmp, msg.sender->id);
			msg.sender->customed_grpmbr_data = &(new_data_tmp.members_data.back());
			return;
		}
	}

#ifdef ALPHA_NO_NULL_JSON
	//��ֹδ�������ݴ洢�ļ��е���pJsonFile_tΪnullptr��������
	msg.sender->customed_grpmbr_data = &EMPTY_JSON_DATA;
#endif // ALPHA_NO_NULL_JSON
}

void createNewCQUserData(CQUserDataList& user_data, std::string user_id){
	user_data.emplace_back();
	jsonFile& new_user_data = user_data.back();
	new_user_data.file_path = USER_DATA_FOLDER;
	new_user_data.file_name = user_id + ".json";
	new_user_data.identifier = user_id;
	new_user_data.uid = strtoull(user_id.c_str(), NULL, 10);
	new_user_data.json["user_id"] = user_id;
	//customed data
	new_user_data.json["is_operator"] = 0;
	new_user_data.json["favor"] = 0;
	/*
		Other data here...
	*/
	new_user_data.save();
}

void createNewCQGrpmbrData(CQGroupMemberData& group_member_data, std::string user_id){
	group_member_data.members_data.emplace_back();
	jsonFile& new_member_data = group_member_data.members_data.back();
	new_member_data.file_path = GROUP_DATA_FOLDER + group_member_data.group_id + "\\";
	new_member_data.file_name = user_id + ".json";
	new_member_data.identifier = user_id;
	new_member_data.uid = strtoull(user_id.c_str(), NULL, 10);
	new_member_data.json["user_id"] = user_id;
	//customed data
	new_member_data.json["permission"] = DEFAULT_PERMISSION_LEVEL;
	/*
		Other data here...
	*/
	new_member_data.save();
}

int createNewCQGroupData(CQGroupList& group_list, std::string group_id){
	if (createFolder(GROUP_DATA_FOLDER + group_id + "\\") == 0) {
		group_list.emplace_back();
		group_list.back().id = group_id;
		jsonFile& new_group_data = group_list.back().group_data;
		new_group_data.file_path = GROUP_DATA_FOLDER + group_id + "\\";
		new_group_data.file_name = GROUP_DATA_FILE_NAME;
		new_group_data.identifier = group_id;
		new_group_data.uid = strtoull(group_id.c_str(), NULL, 10);
		new_group_data.json["group_id"] = group_id;
		//customed data
		new_group_data.json["repeat"] = DEFAULT_REPEAT_TIMES;
		/*
			Other data here...
		*/
		new_group_data.save();
		return 1;
	}
	else {
		return 0;
	}
}

int isGroupAvailable(CQGroupMsg& group_msg){
	int is_ava = 0;
	if (!loadIntByKeyword("available", group_msg.group->group_data.json, is_ava)) {
		group_msg.group->group_data.json["available"] = 0;
		group_msg.group->group_data.save();
		return 0;
	}
	return is_ava;
}

int checkGroupStart(CQGroupMsg& group_msg){
	std::string msg_text = group_msg.uniText();
	if (msg_text == "/start" || msg_text == "/����") {
		if (!checkPermissionLevel(group_msg, ALPHA_START_PERMISSION_LEVEL)) {
			return 0;
		}
		if (!isGroupAvailable(group_msg)) {
			group_msg.group->group_data.json["available"] = 1;
			group_msg.group->group_data.save();
			sendGroupMsg(group_msg.group->id, ALPHA_START_MSG, 0);
			return 1;
		}
		else {
			sendGroupMsg(group_msg.group->id, ALPHA_ALREADY_STARTED, 0);
			return 0;
		}
	}
	return 0;
}

int randomInt(int lb, int ub){
	static std::default_random_engine rand_engine;
	static bool is_init = false;
	std::uniform_int_distribution<int> rand_int(lb, ub);
	if (!is_init) {
		rand_engine.seed(time(0));
		is_init = true;
	}

	return rand_int(rand_engine);
}

double randomDouble(double lb, double ub){
	static std::default_random_engine rand_engine;
	static bool is_init = false;
	std::uniform_real_distribution<double> rand_dbl(lb, ub);
	if (!is_init) {
		rand_engine.seed(time(0));
		is_init = true;
	}

	return rand_dbl(rand_engine);
}

void register_enableGroup(std::vector<CQEvent>& event_list){
	CQEvent event_tmp;
	//refer to checkGroupStart, but needless for eventRegister to execute;
	//thus set trig_type to TRIG_NEVER.
	event_tmp.event_func = nullptr;
	event_tmp.event_type = EVENT_GROUP;
	event_tmp.trig_type = TRIG_NEVER;
	event_tmp.msg_codetype = CODE_UTF8;
	event_tmp.tag.index = 0;
	event_tmp.tag.permission = ALPHA_START_PERMISSION_LEVEL;
	event_tmp.tag.name = "����������";
	event_tmp.tag.example = "/start(/����)";
	event_tmp.tag.description = "�ڵ�ǰȺ�������û����ˡ�";

	event_list.push_back(event_tmp);
}

int disableGroup(CQmsg& msg){
	int is_ava = 0;
	CQGroupMsg& group_msg = (CQGroupMsg&)msg;
	if (!checkPermissionLevel(group_msg, ALPHA_START_PERMISSION_LEVEL)) {
		return 0;
	}
	group_msg.group->group_data.json["available"] = 0;
	group_msg.group->group_data.save();
	sendGroupMsg(group_msg.group->id, ALPHA_STOP_MSG, 0);
	return 1;
}

void register_disableGroup(std::vector<CQEvent>& event_list){
	CQEvent event_tmp;
	event_tmp.event_func = disableGroup;
	event_tmp.event_type = EVENT_GROUP;
	event_tmp.trig_type = MSG_MATCH;
	event_tmp.trig_msg.emplace_back("/stop");
	event_tmp.trig_msg.emplace_back("/ֹͣ");
	event_tmp.msg_codetype = CODE_UTF8;
	event_tmp.tag.index = 0;
	event_tmp.tag.permission = ALPHA_START_PERMISSION_LEVEL;
	event_tmp.tag.name = "�رջ�����";
	event_tmp.tag.example = "/stop(/ֹͣ)";
	event_tmp.tag.description = "�ڵ�ǰȺ���йرջ����ˡ�";

	event_list.push_back(event_tmp);
}
