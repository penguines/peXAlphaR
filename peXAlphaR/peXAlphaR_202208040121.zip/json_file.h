#ifndef JSON_FILE_H
#define JSON_FILE_H

#include <string>
#include <json/json.h>
#include <fstream>

class jsonFile {
public:
	std::string file_path;
	std::string file_name;
	std::string identifier;

	Json::Value json;

	jsonFile(std::string fp = "", std::string fn = "", std::string id = "");
	virtual ~jsonFile();
	
	int save();
	int load();
	void clear();
};

typedef jsonFile JsonFile_t;
typedef jsonFile* pJsonFile_t;

#endif // !JSON_FILE_H
