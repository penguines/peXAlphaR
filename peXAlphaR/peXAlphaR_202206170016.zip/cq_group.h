#ifndef CQ_GROUP_H
#define CQ_GROUP_H

#include <string>
#include <json/json.h>
#include "load_from_json.h"

class CQgroup {
public:
	std::string id;

	CQgroup();
	CQgroup(Json::Value& group);
	virtual ~CQgroup();

	virtual void load(Json::Value& group);
	virtual void clear();
private:
	void loadID(Json::Value& group);
};

typedef CQgroup		CQgroup_t;
typedef CQgroup*	pCQgroup_t;

#endif
