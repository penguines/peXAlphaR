#ifndef LOAD_FROM_JSON_H
#define LOAD_FROM_JSON_H

#include <string>
#include <json/json.h>

int loadStringByKeyword(std::string keyword, Json::Value& json, std::string& str_dst);
int loadIntByKeyword(std::string keyword, Json::Value& json, int& int_dst);

#endif // !LOAD_FROM_JSON_H
