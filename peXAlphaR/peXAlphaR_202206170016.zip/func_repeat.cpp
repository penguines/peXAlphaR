#include "func_repeat.h"

static int repeat_times = 3;

int repeatMsg(CQmsg& msg){
	CQGroupMsg* group_msg;
	static Json::Value latestMsg;
	std::string msg_tmp, msg_text;
	int repeat_cnt = 0;
	if (msg.msg_type != MSG_GROUP) {
		return 0;
	}

	group_msg = (CQGroupMsg*)&msg;
	msg_text = group_msg->text();
	if (latestMsg.isMember(group_msg->group->id)) {
		loadStringByKeyword("message", latestMsg[group_msg->group->id], msg_tmp);
		if (msg_tmp == msg_text) {
			loadIntByKeyword("repeat", latestMsg[group_msg->group->id], repeat_cnt);
			repeat_cnt++;
			if (repeat_cnt >= repeat_times) {
				sendGroupMsg(group_msg->group->id, UrlSpec(group_msg->raw_message), 1);
				latestMsg[group_msg->group->id]["repeat"] = 1;
			}
			else {
				latestMsg[group_msg->group->id]["repeat"] = repeat_cnt;
			}
			return repeat_cnt;
		}
		else {
			latestMsg[group_msg->group->id]["repeat"] = 1;
			latestMsg[group_msg->group->id]["message"] = msg_text;
			return 0;
		}
	}
	else {
		latestMsg[group_msg->group->id]["repeat"] = 1;
		latestMsg[group_msg->group->id]["message"] = msg_text;
		return 0;
	}
	return 0;
}

void register_repeat(std::vector<CQEvent>& event_list){
	CQEvent repeat_event;
	repeat_event.event_func = repeatMsg;
	repeat_event.event_type = EVENT_GROUP;
	repeat_event.trig_type = TRIG_ALWAYS;
	repeat_event.msg_codetype = CODE_UTF8;
	repeat_event.tag.index = 0;
	repeat_event.tag.name = "����";

	event_list.push_back(repeat_event);
}
