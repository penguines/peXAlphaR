#include "cq_api_post.h"

//0-> UTF8 ; 1->GB2312
void sendHttpData(std::string group_id, char* msg, int mode = 0) {
	std::string d_data = encodeNL(msg);
	std::string m_data = "/send_group_msg?group_id=" + group_id + "&message=" + (mode ? d_data : UrlUTF8((char*)encodeNL(msg).c_str()));
	struct hostent* p_hostent = gethostbyname(post_host.c_str());
	if (p_hostent == NULL)
	{
		return;
	}
	sockaddr_in addr_server;
	addr_server.sin_family = AF_INET;
	addr_server.sin_addr.s_addr = inet_addr(post_host.c_str());
	addr_server.sin_port = htons(post_port);
	memcpy(&(addr_server.sin_addr), p_hostent->h_addr_list[0], sizeof(addr_server.sin_addr));
	int sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	int res = connect(sock, (sockaddr*)&addr_server, sizeof(addr_server));
	if (res == -1)
	{
		std::cout << "Connect failed " << std::endl;
		closesocket(sock);
		return;
	}
	std::string sendData = "GET " + m_data + " HTTP/1.1\r\n";
	sendData += "Host:" + post_host + "\r\n";
	sendData += "Connection:close\r\n";
	sendData += "\r\n";
	send(sock, sendData.c_str(), sendData.size(), 0);
	std::string  m_readBuffer;
	if (m_readBuffer.empty())
		m_readBuffer.resize(32767);
	int readCount = recv(sock, &m_readBuffer[0], m_readBuffer.size(), 0);
	std::cout << "Request: " << sendData.c_str() << " and response:" << m_readBuffer.c_str() << std::endl;
	closesocket(sock);
}

std::string sendCommand(std::string command) {
	struct hostent* p_hostent = gethostbyname(post_host.c_str());
	if (p_hostent == NULL)
	{
		return "";
	}
	sockaddr_in addr_server;
	addr_server.sin_family = AF_INET;
	addr_server.sin_addr.s_addr = inet_addr(post_host.c_str());
	addr_server.sin_port = htons(post_port);
	memcpy(&(addr_server.sin_addr), p_hostent->h_addr_list[0], sizeof(addr_server.sin_addr));
	int sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	int res = connect(sock, (sockaddr*)&addr_server, sizeof(addr_server));
	if (res == -1)
	{
		std::cout << "Connect failed " << std::endl;
		closesocket(sock);
		return "";
	}

	std::string sendData = "GET " + command + " HTTP/1.1\r\n";
	sendData += "Host:" + post_host + "\r\n";
	sendData += "Connection:close\r\n";
	sendData += "\r\n";
	send(sock, sendData.c_str(), sendData.size(), 0);
	std::string m_readBuffer;
	char* recvTmp = (char*)malloc(65537 * sizeof(char));
	int readCount = recv(sock, recvTmp, 65536, 0);
	recvTmp[readCount] = '\0';
	m_readBuffer = recvTmp;
	int content_length, cl_loc, cntTmp = readCount;
	std::string recvStr = m_readBuffer;
	if (m_readBuffer.length() >= 4096) {
		recvStr = recvStr.substr(recvStr.find_first_of('{'));
		while (cntTmp > 0) {
			cntTmp = recv(sock, recvTmp, 65536, 0);
			readCount += cntTmp;
			recvTmp[cntTmp] = '\0';
			m_readBuffer += recvTmp;
		}
	}
	free(recvTmp);
	closesocket(sock);
	return m_readBuffer;
}

void sendGroupMsg(std::string group_id, char* msg) {
	sendHttpData(group_id, msg, 0);
}

void sendGroupMsg(std::string group_id, std::string msg, int isUTF8) {
	char tmp[10000] = { '\0' };
	strcpy(tmp, msg.c_str());
	if (isUTF8) sendHttpData(group_id, tmp, 1);
	else sendHttpData(group_id, tmp, 0);
}

void sendPrivateMsg(std::string id, std::string msg) {
	sendCommand("/send_private_msg?user_id=" + id + "&message=" + UrlUTF8((char*)encodeNL(msg).c_str()));
}

void sendPrivateMsg(std::string id, std::string msg, int isUTF8) {
	if (!isUTF8)sendPrivateMsg(id, msg);
	else sendCommand("/send_private_msg?user_id=" + id + "&message=" + encodeNL(msg));
}