#ifndef FUNC_REPEAT_H
#define FUNC_REPEAT_H

#include "cq_msg.h"
#include "cq_api_post.h"
#include "cq_transcoder.h"
#include "cq_event.h"

int repeatMsg(CQmsg& msg);
void register_repeat(std::vector<CQEvent>& event_list);

#endif // !FUNC_REPEAT_H
