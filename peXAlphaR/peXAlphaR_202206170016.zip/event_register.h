#ifndef EVENT_REGISTER_H
#define EVENT_REGISTER_H

#include <vector>
#include "cq_event.h"

typedef std::vector<CQEvent> eventList;
typedef std::vector<void(*)(eventList&)> registerFuncList;

class eventRegister {
public:
	eventRegister();
	virtual ~eventRegister();

	void append(void (*reg_func)(eventList&));
	int registerEvents();
	int executeEvents(CQmsg& msg);
	size_t eventSize();

private:
	eventList m_events;
	registerFuncList m_regfuncs;
};

#endif // !EVENT_REGISTER_H
