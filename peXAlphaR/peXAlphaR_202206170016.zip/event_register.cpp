#include "event_register.h"

eventRegister::eventRegister(){
}

eventRegister::~eventRegister(){
	this->m_events.clear();
	this->m_regfuncs.clear();
}

void eventRegister::append(void(*reg_func)(eventList&)){
	this->m_regfuncs.push_back(reg_func);
}

int eventRegister::registerEvents(){
	int cnt = 0;
	for (auto iter = this->m_regfuncs.begin(); iter != this->m_regfuncs.end(); iter++) {
		(*iter)(this->m_events);
		cnt++;
	}
	return cnt;
}

int eventRegister::executeEvents(CQmsg& msg){
	int cnt = 0;
	for (auto iter = this->m_events.begin(); iter != this->m_events.end(); iter++) {
		if ((iter->trig(msg)) > 0) {
			cnt++;
		}
	}
	return cnt;
}

size_t eventRegister::eventSize(){
	return m_events.size();
}
