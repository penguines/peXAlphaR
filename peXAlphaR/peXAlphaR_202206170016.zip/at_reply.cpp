#include "at_reply.h"

int atSB(CQmsg& msg){
	CQGroupMsg* group_msg = (CQGroupMsg*)&msg;
	sendGroupMsg(group_msg->group->id, "[CQ:at,qq=" + group_msg->sender->id + "] [CQ:image,file=file:///F:/peXAlpha_Reborn/atsb.jpg]", 0);
	return 0;
}

int condition_atSB(CQmsg& msg){
	std::string str_tmp;
	if (!msg.content.isArray()) {
		return 0;
	}
	for (int i = 0; i < msg.content.size(); i++) {
		loadStringByKeyword("type", msg.content[i], str_tmp);
		if (str_tmp == "at") {
			if (msg.content[i].isMember("data")) {
				loadStringByKeyword("qq", msg.content[i]["data"], str_tmp);
				if (str_tmp == msg.self_id) {
					return 1;
				}
			}
		}
	}
	return 0;
}

void register_atSB(std::vector<CQEvent>& event_list){
	CQEvent event_tmp;
	event_tmp.event_func = atSB;
	event_tmp.event_type = EVENT_GROUP;
	event_tmp.custom_condition = condition_atSB;
	event_tmp.trig_type = TRIG_CUSTOMIZE;
	event_tmp.msg_codetype = CODE_UTF8;
	event_tmp.tag.index = 0;
	event_tmp.tag.name = "����ɵ��";

	event_list.push_back(event_tmp);
}
