#ifndef CQ_API_POST_H
#define CQ_API_POST_H

#include <iostream>
#include <string>
#include <vector>
#include <WinSock2.h>
#include <windows.h>
#include "cq_transcoder.h"

static std::string post_host = "127.0.0.1";
static int post_port = 5700;

//previous API
void sendHttpData(std::string, char*, int);
//latest API
std::string sendCommand(std::string command);

void sendGroupMsg(std::string group_id, char* msg);
void sendGroupMsg(std::string group_id, std::string msg, int isUTF8);
void sendPrivateMsg(std::string id, std::string msg);	//msg as UTF8
void sendPrivateMsg(std::string id, std::string msg, int isUTF8);

#endif
