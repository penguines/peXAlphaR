#ifndef CQ_TRANSCODER_H
#define CQ_TRANSCODER_H

#include <string>
#include <WinSock2.h>

std::string encodeNL(std::string input);

std::string UrlUTF8(const char* str);
std::string UrlUTF8(std::string str);

std::string utf8ToGB2312(const char* cstr_utf8);
std::string utf8ToGB2312(std::string str_utf8);

#endif // !CQ_TRANSCODER_H

