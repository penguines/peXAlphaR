#include "cq_api_post.h"

static std::string post_host;
static int post_port;

#ifndef ALPHA_POST_WITH_JSON

//0-> UTF8 ; 1->GB2312
void sendHttpData(std::string group_id, const char* msg, int mode = 0) {
	std::string d_data = encodeNL(msg);
	std::string m_data = "/send_group_msg?group_id=" + group_id + "&message=" + (mode ? d_data : UrlUTF8((char*)encodeNL(msg).c_str()));
	struct hostent* p_hostent = gethostbyname(post_host.c_str());
	if (p_hostent == NULL){
		return;
	}
	sockaddr_in addr_server;
	addr_server.sin_family = AF_INET;
	addr_server.sin_addr.s_addr = inet_addr(post_host.c_str());
	addr_server.sin_port = htons(post_port);
	memcpy(&(addr_server.sin_addr), p_hostent->h_addr_list[0], sizeof(addr_server.sin_addr));
	int sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	int res = connect(sock, (sockaddr*)&addr_server, sizeof(addr_server));
	if (res == -1){
#ifdef ALPHA_SHOW_ALL_INFO
		std::cout << "Connect failed " << std::endl;
#endif
		closesocket(sock);
		return;
	}
	std::string sendData = "GET " + m_data + " HTTP/1.1\r\n";
	sendData += "Host:" + post_host + "\r\n";
	sendData += "Connection:close\r\n";
	sendData += "\r\n";
	send(sock, sendData.c_str(), sendData.size(), 0);
	std::string  m_readBuffer;
	if (m_readBuffer.empty()) {
		m_readBuffer.resize(32767);
	}
	int readCount = recv(sock, &m_readBuffer[0], m_readBuffer.size(), 0);
#ifdef ALPHA_SHOW_ALL_INFO
	std::cout << "Request: " << sendData.c_str() << " and response:" << m_readBuffer.c_str() << std::endl;
#endif
	closesocket(sock);
}

void sendGroupMsg(std::string group_id, std::string msg, int isUTF8) {
	if (isUTF8) sendHttpData(group_id, msg.c_str(), 1);
	else sendHttpData(group_id, msg.c_str(), 0);
}

void sendPrivateMsg(std::string id, std::string msg, int isUTF8) {
	if (!isUTF8) {
		sendCommand("/send_private_msg?user_id=" + id + "&message=" + UrlUTF8((char*)encodeNL(msg).c_str()));
	}
	else {
		sendCommand("/send_private_msg?user_id=" + id + "&message=" + encodeNL(msg));
	}
}

#else

void sendGroupMsg(std::string group_id, std::string msg, int isUTF8) {
	Json::Value json;
	json["type"] = "text";
	if (!isUTF8) {
		msg = GB2312ToUTF8(msg);
	}
	json["data"]["text"] = msg;
	sendGroupMsg(group_id, json);
}

void sendGroupMsg(std::string group_id, const Json::Value& json){
	Json::FastWriter fast_writer;
	sendCommand("/send_group_msg?group_id=" + group_id + "&message=" + urlEncode(fast_writer.write(json)));
}

void sendPrivateMsg(std::string id, std::string msg, int isUTF8) {
	Json::Value json;
	json["type"] = "text";
	if (!isUTF8) {
		msg = GB2312ToUTF8(msg);
	}
	json["data"]["text"] = msg;
	sendPrivateMsg(id, json);
}

void sendPrivateMsg(std::string id, const Json::Value& json) {
	Json::FastWriter fast_writer;
	sendCommand("/send_private_msg?user_id=" + id + "&message=" + urlEncode(fast_writer.write(json)));
}

#endif // !ALPHA_POST_WITH_JSON

std::string sendCommand(std::string command) {
	struct hostent* p_hostent = gethostbyname(post_host.c_str());
	if (p_hostent == NULL) {
		return "";
	}
	sockaddr_in addr_server;
	addr_server.sin_family = AF_INET;
	addr_server.sin_addr.s_addr = inet_addr(post_host.c_str());
	addr_server.sin_port = htons(post_port);
	memcpy(&(addr_server.sin_addr), p_hostent->h_addr_list[0], sizeof(addr_server.sin_addr));
	int sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	int res = connect(sock, (sockaddr*)&addr_server, sizeof(addr_server));
	if (res == -1) {
#ifdef ALPHA_SHOW_ALL_INFO
		std::cout << "Connect failed " << std::endl;
#endif
		closesocket(sock);
		return "";
	}

	std::string sendData = "GET " + command + " HTTP/1.1\r\n";
	sendData += "Host:" + post_host + "\r\n";
	sendData += "Connection:close\r\n";
	sendData += "\r\n";
	send(sock, sendData.c_str(), sendData.size(), 0);
	std::string m_readBuffer;
	char* recvTmp = (char*)malloc(65537 * sizeof(char));
	int readCount = recv(sock, recvTmp, 65536, 0);
	recvTmp[readCount] = '\0';
	m_readBuffer = recvTmp;
	int content_length, cl_loc, cntTmp = readCount;
	std::string recvStr = m_readBuffer;
	if (m_readBuffer.length() >= 4096) {
		recvStr = recvStr.substr(recvStr.find_first_of('{'));
		while (cntTmp > 0) {
			cntTmp = recv(sock, recvTmp, 65536, 0);
			readCount += cntTmp;
			recvTmp[cntTmp] = '\0';
			m_readBuffer += recvTmp;
		}
	}
	free(recvTmp);
	closesocket(sock);
	return m_readBuffer;
}

void sendReply(CQmsg& msg, std::string reply, int isUTF8){
	switch (msg.msg_type) {
	case MSG_GROUP:
		sendGroupMsg(((CQGroupMsg*)&msg)->group->id, reply, isUTF8);
		break;
	case MSG_PRIVATE:
		sendPrivateMsg(((CQPrivateMsg*)&msg)->sender->id, reply, isUTF8);
		break;
	}
}

void cq_post_api::setPostIP(std::string host, int port){
	post_host = host;
	post_port = port;
}
