#include "alpha_permissions.h"

static std::string owner_id;
static std::vector<jsonFile>* users_data;

void alpha_permission::setBotOwner(std::string id) {
	owner_id = id;
}

void alpha_permission::setUserData(std::vector<jsonFile>& user_data){
	users_data = &user_data;
}

int checkIsOperator(CQuser& user){
	int is_op = 0;
	if (user.customed_user_data != nullptr) {
		if (loadIntByKeyword("is_operator", user.customed_user_data->json, is_op)) {
			if (is_op) {
				return 1;
			}
			else {
				return 0;
			}
		}
		else {
			user.customed_user_data->json["is_operator"] = 0;
			user.customed_user_data->save();
		}
	}
	return 0;
}

int checkIsBlacklisted(CQuser& user){
	return 0;
}

int checkPermissionLevel(int user_permission_level, int required_permission_level, std::string& response_msg){
	if (user_permission_level >= required_permission_level) {
		response_msg = PERMISSION_ACCEPTED;
		return 1;
	}
	else {
		response_msg = PERMISSION_DENIED;
		return 0;
	}
}

int checkPermissionLevel(CQGroupMsg& group_msg, int required_permission_level){
	int cur_permission_lvl = DEFAULT_PERMISSION_LEVEL;
	std::string response_msg;
	int check_result;

	if (group_msg.sender->id == owner_id) {
		return 1;
	}
	if (checkIsBlacklisted(*(group_msg.sender))) {
		return 0;
	}
	if (checkIsOperator(*(group_msg.sender))) {
		return 1;
	}

	cur_permission_lvl = getGrpmbrPermissionLvl(*(group_msg.sender));
	if (cur_permission_lvl == -1) {
		sendGroupMsg(group_msg.group->id, PERMISSION_UNEXISTED, 0);
		return 0;
	}

	check_result = checkPermissionLevel(cur_permission_lvl, required_permission_level, response_msg);
	if (!response_msg.empty()) {
		sendGroupMsg(group_msg.group->id, response_msg, 0);
	}
	return check_result;
}

int checkPermission(CQmsg& msg, int required_permission_level){
	switch (msg.msg_type) {
	case MSG_GROUP:
		return checkPermissionLevel((CQGroupMsg&)msg, required_permission_level);
	case MSG_PRIVATE:
		if (checkIsBlacklisted(*(((CQPrivateMsg*)&msg)->sender))) {
			return 0;
		}
		return 1;
	}
	return 0;
}

int getGrpmbrPermissionLvl(CQGroupMember& group_member){
	int cur_permission_lvl = DEFAULT_PERMISSION_LEVEL;
	if (group_member.customed_grpmbr_data == nullptr) {
		return -1;
	}
	if (!loadIntByKeyword("permission", group_member.customed_grpmbr_data->json, cur_permission_lvl)) {
		group_member.customed_grpmbr_data->json["permission"] = DEFAULT_PERMISSION_LEVEL;
		group_member.customed_grpmbr_data->save();
	}
	cur_permission_lvl += group_member.permission_addition;
	return cur_permission_lvl;
}


int setOperator(CQmsg& msg){
	std::string request_id;
	switch (msg.msg_type) {
	case MSG_GROUP:
		request_id = ((CQGroupMsg*)&msg)->sender->id;
		break;
	case MSG_PRIVATE:
		request_id = ((CQPrivateMsg*)&msg)->sender->id;
		break;
	default:
		return 0;
	}
	if (request_id != owner_id) {
		return 0;
	}

	std::regex reg("^/op\\s*([0-9]*)\\s*$");
	std::smatch reg_result;
	std::string msg_text = msg.text();
	std::regex_search(msg_text, reg_result, reg);
	msg_text = reg_result[1].str();

	for (auto iter = users_data->begin(); iter != users_data->end(); iter++) {
		if (iter->identifier == msg_text) {
			iter->json["is_operator"] = 1;
			iter->save();
			sendReply(msg, "������" + msg_text + "Ϊ����Ա��");
			return 1;
		}
	}
	sendReply(msg, "δ�ҵ��û�������ʧ�ܡ�");
	return 0;
}

void register_setOperator(std::vector<CQEvent>& event_list){
	CQEvent event_tmp;
	event_tmp.event_func = setOperator;
	event_tmp.event_type = EVENT_ALL;
	event_tmp.trig_type = MSG_REGEX;
	event_tmp.trig_regex = "^/op\\s*([0-9]*)\\s*$";
	event_tmp.msg_codetype = CODE_UTF8;
	event_tmp.tag.index = 0;
	event_tmp.tag.permission = SET_OP_PERMISSION_LEVEL;
	event_tmp.tag.name = "���ù���Ա";
	event_tmp.tag.example = "/op [�˺�]";
	event_tmp.tag.description = "�����µĻ����˹���Ա(ȫ����Ч)��";

	event_list.push_back(event_tmp);
}

int delOperator(CQmsg& msg){
	std::string request_id;
	switch (msg.msg_type) {
	case MSG_GROUP:
		request_id = ((CQGroupMsg*)&msg)->sender->id;
		break;
	case MSG_PRIVATE:
		request_id = ((CQPrivateMsg*)&msg)->sender->id;
		break;
	default:
		return 0;
	}
	if (request_id != owner_id) {
		return 0;
	}

	std::regex reg("^/deop\\s*([0-9]*)\\s*$");
	std::smatch reg_result;
	std::string msg_text = msg.text();
	std::regex_search(msg_text, reg_result, reg);
	msg_text = reg_result[1].str();

	for (auto iter = users_data->begin(); iter != users_data->end(); iter++) {
		if (iter->identifier == msg_text) {
			iter->json["is_operator"] = 0;
			iter->save();
			sendReply(msg, msg_text + "�����ǹ���Ա��");
			return 1;
		}
	}
	sendReply(msg, "δ�ҵ��û�������ʧ�ܡ�");
	return 0;
}

void register_delOperator(std::vector<CQEvent>& event_list){
	CQEvent event_tmp;
	event_tmp.event_func = delOperator;
	event_tmp.event_type = EVENT_ALL;
	event_tmp.trig_type = MSG_REGEX;
	event_tmp.trig_regex = "^/deop\\s*([0-9]*)\\s*$";
	event_tmp.msg_codetype = CODE_UTF8;
	event_tmp.tag.index = 0;
	event_tmp.tag.permission = SET_OP_PERMISSION_LEVEL;
	event_tmp.tag.name = "ɾ������Ա";
	event_tmp.tag.example = "/deop [�˺�]";
	event_tmp.tag.description = "�Ƴ����еĻ����˹���Ա(ȫ����Ч)��";

	event_list.push_back(event_tmp);
}
