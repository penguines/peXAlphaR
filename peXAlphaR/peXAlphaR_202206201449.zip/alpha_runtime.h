#ifndef ALPHA_RUNTIME_H
#define ALPHA_RUNTIME_H

#include <string>
#include <vector>
#include "cq_msg.h"
#include "json_file.h"
#include "alpha_inits.h"

//necessary for createNewData functions.
void setGroupDataFolder(std::string folder_path);
void setUserDataFolder(std::string folder_path);

void loadCQUserData(CQuser& user, CQUserDataList& user_data);
void loadCQmsgUserData(CQPrivateMsg& msg, CQUserDataList& user_data);
void loadCQmsgUserData(CQGroupMsg& msg, CQUserDataList& user_data);
void loadCQmsgGroupData(CQGroupMsg& msg, CQGroupList& groups_data, CQGrpMbrDataList& groups_member_data);
void createNewCQUserData(CQUserDataList& user_data, std::string user_id);
void createNewCQGrpmbrData(CQGroupMemberData& member_data, std::string user_id);
int createNewCQGroupData(CQGroupList& group_list, std::string group_id);

#endif // !ALPHA_RUNTIME_H
