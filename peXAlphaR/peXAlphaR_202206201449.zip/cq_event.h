#ifndef CQ_EVENT_H
#define CQ_EVENT_H

#include <regex>
#include "cq_msg.h"

typedef enum eventTriggerType { TRIG_NEVER = 0, TRIG_ALWAYS = 1, MSG_MATCH = 2, MSG_CONTAIN = 4, MSG_REGEX = 8, TRIG_CUSTOMIZE = 16 };
typedef enum eventType { EVENT_NONE = 0, EVENT_ALL = 1, EVENT_PRIVATE = 2, EVENT_GROUP = 4};
typedef enum messageCodeType { CODE_UNICODE = 0, CODE_UTF8 = 1 };

typedef struct eventTag {
	unsigned int index;
	std::string name;
};

class CQEvent {
public:
	eventTag tag;

	int (*event_func)(CQmsg& msg);
	//Custom trigger condition function.Returning 1 for trig.
	int (*custom_condition)(CQmsg& msg);
	
	int trig_type;
	int event_type;
	//Code type of input CQmsg
	int msg_codetype;

	//default string as unicode
	std::string trig_msg;
	std::string trig_regex;

	CQEvent(int tag_index = 0,\
			std::string tag_name = "",\
			int (*event_function)(CQmsg& msg) = nullptr,\
			int (*condition_function)(CQmsg& msg) = nullptr,\
			int trig_typ = eventTriggerType::TRIG_NEVER,\
			int event_typ = eventType::EVENT_NONE,\
			int msg_codetyp = messageCodeType::CODE_UTF8,\
			std::string trigger_msg = "",\
			std::string trigger_reg = "");

	virtual ~CQEvent();

	//Auto check, ban & unban according to event_type.
	int isBanned(std::string id);
	int ban(std::string id);
	int unban(std::string id);

	//Group
	int isBannedGroup(std::string id);
	int banGroup(std::string id);
	int unbanGroup(std::string id);

	//User
	int isBannedUser(std::string id);
	int banUser(std::string id);
	int unbanUser(std::string id);

	int trig(CQmsg& msg);

private:
	std::vector<std::string> banned_group;
	std::vector<std::string> banned_user;

	int checkTriggerCondition(CQmsg& msg);
};

template <typename _T>
int searchFromVector(std::vector<_T>& vec, _T key);

#endif // !CQ_EVENT