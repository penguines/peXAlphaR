#ifndef AT_REPLY_H
#define AT_REPLY_H

#include <string>
#include "cq_api_post.h"
#include "cq_event.h"

int atSB(CQmsg& msg);
int condition_atSB(CQmsg& msg);
void register_atSB(std::vector<CQEvent>& event_list);

#endif // !AT_REPLY_H

