﻿#include <WinSock2.h>
#include <iostream>
#include <string>
#include <vector>
#include <windows.h>
#include <json/json.h>
#include "json_file.h"
#include "cq_connection.h"
#include "cq_api_post.h"
#include "cq_msg.h"
#include "cq_event.h"
#include "event_register.h"
#include "func_repeat.h"
#include "at_reply.h"
#include "alpha_inits.h"
#include "alpha_runtime.h"
#include "alpha_permissions.h"

const std::string owner = "843738442";

const std::string GROUP_DATA_PATH = "data\\groups\\";
const std::string USER_DATA_PATH = "data\\users\\";
std::string RUN_PATH;
std::string recv_host = "127.0.0.1";
int recv_port = 8010;

eventRegister events_reg;
CQGroupList groups_data;
CQGrpMbrDataList groups_members_data;
CQUserDataList users_data;

void initialize();

void messageProcess(Json::Value& message);
void setEvents(eventRegister& event_reg);

int main() {
	std::string recv_str;

	Json::Reader json_reader;
	Json::Value recv_json;

	initialize();
	setEvents(events_reg);
	events_reg.registerEvents();

	SOCKET serv_sock;
	createConnection(serv_sock, recv_host.c_str(), recv_port);
	listen(serv_sock, 10000);

	std::string msg_temp;

	while (1) {
		recvJsonMessage(serv_sock, recv_str);
		std::cout << recv_str << std::endl;

		if (json_reader.parse(recv_str, recv_json)) {
			loadStringByKeyword("post_type", recv_json, msg_temp);
			if (msg_temp == "message") {
				messageProcess(recv_json);
			}
		}

	}
	
	closeConnection(serv_sock);

	WSACleanup();
}

void initialize(){
	setlocale(LC_ALL, "chs");
	std::wcout.imbue(std::locale(""));
	WSADATA wsaData;
	WSAStartup(MAKEWORD(2, 2), &wsaData);

	//permission init
	alpha_permission::setBotOwner(owner);
	alpha_permission::setUserData(users_data);

	//data init
	RUN_PATH = getRunPath();
	initGroupsData(RUN_PATH + GROUP_DATA_PATH, groups_data, groups_members_data);
	setGroupDataFolder(RUN_PATH + GROUP_DATA_PATH);
	initUsersData(RUN_PATH + USER_DATA_PATH, users_data);
	setUserDataFolder(RUN_PATH + USER_DATA_PATH);
}

void messageProcess(Json::Value& message) {
	std::string str_temp;

	CQPrivateMsg private_msg;
	CQGroupMsg group_msg;
	CQmsg* ptr_general_msg;

	loadStringByKeyword("message_type", message, str_temp);
	if (str_temp == "private") {
		private_msg.load(message);
		loadCQmsgUserData(private_msg, users_data);
		ptr_general_msg = &private_msg;
	}
	else if (str_temp == "group") {
		group_msg.load(message);
		loadCQmsgUserData(group_msg, users_data);
		loadCQmsgGroupData(group_msg, groups_data, groups_members_data);

		std::cout << "[" << utf8ToGB2312(group_msg.sender->nickname) << "]在群 " << group_msg.group->id << " 发送了: ";
		std::cout << group_msg.uniText() << std::endl << std::endl;

		ptr_general_msg = &group_msg;
	}
	else {
		return;
	}

	events_reg.executeEvents(*ptr_general_msg);
}


void setEvents(eventRegister& event_reg) {
	event_reg.append(register_repeat);
	event_reg.append(register_atSB);
	event_reg.append(register_setRepeatTimes);
	event_reg.append(register_setOperator);
	event_reg.append(register_delOperator);
}
