#include "cq_event.h"

CQEvent::CQEvent(int tag_index, \
				std::string tag_name, \
				int (*event_function)(CQmsg& msg), \
				int (*condition_function)(CQmsg& msg), \
				int trig_typ, \
				int event_typ, \
				int msg_codetyp, \
				std::string trigger_msg,\
				std::string trigger_reg){

	this->tag.index = tag_index;
	this->tag.name = tag_name;
	this->event_func = event_function;
	this->custom_condition = condition_function;
	this->trig_type = trig_typ;
	this->event_type = event_typ;
	this->msg_codetype = msg_codetyp;
	this->trig_msg = trigger_msg;
	this->trig_regex = trigger_reg;
}

CQEvent::~CQEvent() {

}

int CQEvent::isBanned(std::string id) {
	switch (this->event_type) {
	case eventType::EVENT_ALL:
		if (this->isBannedGroup(id) || this->isBannedUser(id)) {
			return 1;
		}
		else {
			return 0;
		}
	case eventType::EVENT_GROUP:
		return this->isBannedGroup(id);
	case eventType::EVENT_PRIVATE:
		return this->isBannedUser(id);
	}
	return 0;
}

int CQEvent::ban(std::string id) {
	int bg = 0, bu = 0;
	switch (this->event_type) {
	case eventType::EVENT_ALL:
		bg = this->banGroup(id);
		bu = this->banUser(id);
		if (bg == 1 || bu == 1) {
			return 1;
		}
		else {
			return 0;
		}
	case eventType::EVENT_GROUP:
		return this->banGroup(id);
	case eventType::EVENT_PRIVATE:
		return this->banUser(id);
	}
	return 0;
}

int CQEvent::unban(std::string id) {
	int unbg = 0, unbu = 0;
	switch (this->event_type) {
	case eventType::EVENT_ALL:
		unbg = this->unbanGroup(id);
		unbu = this->unbanUser(id);
		if (unbg == 1 || unbu == 1) {
			return 1;
		}
		else {
			return 0;
		}
	case eventType::EVENT_GROUP:
		return this->unbanGroup(id);
	case eventType::EVENT_PRIVATE:
		return this->unbanUser(id);
	}
	return 0;
}

int CQEvent::isBannedGroup(std::string id) {
	if (searchFromVector<std::string>(this->banned_group, id)) {
		return 1;
	}
	else {
		return 0;
	}
}

int CQEvent::banGroup(std::string id) {
	if (!this->isBannedGroup(id)) {
		this->banned_group.push_back(id);
		return 1;
	}
	else {
		return 0;
	}
}

int CQEvent::unbanGroup(std::string id) {
	for (auto iter = this->banned_group.begin(); iter != this->banned_group.end(); iter++) {
		if (*iter == id) {
			this->banned_group.erase(iter);
			return 1;
		}
	}
	return 0;
}

int CQEvent::isBannedUser(std::string id) {
	if (searchFromVector<std::string>(this->banned_user, id)) {
		return 1;
	}
	else {
		return 0;
	}
}

int CQEvent::banUser(std::string id) {
	if (!this->isBannedUser(id)) {
		this->banned_user.push_back(id);
		return 1;
	}
	else {
		return 0;
	}
}

int CQEvent::unbanUser(std::string id) {
	for (auto iter = this->banned_user.begin(); iter != this->banned_user.end(); iter++) {
		if (*iter == id) {
			this->banned_user.erase(iter);
			return 1;
		}
	}
	return 0;
}

int CQEvent::trig(CQmsg& msg){
	CQGroupMsg* p_group_msg;
	CQPrivateMsg* p_private_msg;
	switch (msg.msg_type) {
	case messageType::MSG_GROUP:
		p_group_msg = (CQGroupMsg*)&msg;
		if (this->event_type != eventType::EVENT_GROUP && this->event_type != eventType::EVENT_ALL) {
			return 0;
		}
		if (!this->isBannedGroup(p_group_msg->group->id)) {
			if (this->checkTriggerCondition(msg)) {
				return this->event_func(msg);
			}
			else {
				return 0;
			}
		}
		else {
			return 0;
		}
		break;

	case messageType::MSG_PRIVATE:
		p_private_msg = (CQPrivateMsg*)&msg;
		if (this->event_type != eventType::EVENT_PRIVATE && this->event_type != eventType::EVENT_ALL) {
			return 0;
		}
		if (!this->isBannedUser(p_private_msg->sender->id)) {
			if (this->checkTriggerCondition(msg)) {
				return this->event_func(msg);
			}
			else {
				return 0;
			}
		}
		else {
			return 0;
		}
		break;

	case messageType::MSG_UNDEFINED:
		return 0;
	default:
		return 0;
	}
}

int CQEvent::checkTriggerCondition(CQmsg& msg){
	std::string msg_str;
	std::regex reg;
	switch (this->msg_codetype) {
	case messageCodeType::CODE_UNICODE:
		msg_str = msg.text();
		break;

	case messageCodeType::CODE_UTF8:
		msg_str = msg.uniText();
		break;

	default:
		msg_str = msg.uniText();
	}

	switch (this->trig_type) {
	case eventTriggerType::MSG_MATCH:
		if (msg_str == this->trig_msg) {
			return 1;
		}
		else {
			return 0;
		}

	case eventTriggerType::MSG_CONTAIN:
		if (msg_str.find(this->trig_msg) != std::string::npos) {
			return 1;
		}
		else {
			return 0;
		}

	case eventTriggerType::MSG_REGEX:
		reg.assign(this->trig_regex);
		if (std::regex_match(msg_str, reg)) {
			return 1;
		}
		else {
			return 0;
		}

	case eventTriggerType::TRIG_CUSTOMIZE:
		return this->custom_condition(msg);

	case eventTriggerType::TRIG_ALWAYS:
		return 1;

	case eventTriggerType::TRIG_NEVER:
		return 0;

	default:
		return 0;
	}
}

template<typename _T>
int searchFromVector(std::vector<_T>& vec, _T key) {
	for (auto iter = vec.begin(); iter != vec.end(); iter++) {
		if (*iter == key) {
			return 1;
		}
	}
	return 0;
}