#ifndef ALPHA_INITS_H
#define ALPHA_INITS_H

#include <string>
#include <vector>
#include "alpha_paths.h"
#include "alpha_permissions.h"
#include "json_file.h"
#include "cq_group.h"
#include "func_repeat.h"

#define GROUP_DATA_FILE_NAME "global.json"

typedef std::vector<jsonFile>	jsonFileList;
typedef std::vector<CQgroup>	CQGroupList;
typedef jsonFileList			CQUserDataList;

class CQGroupMemberData{
public:
	std::string group_id;
	jsonFileList members_data;

	CQGroupMemberData();
	~CQGroupMemberData();
};

typedef std::vector<CQGroupMemberData> CQGrpMbrDataList;

void initGroupsData(std::string folder_path, CQGroupList& groups, CQGrpMbrDataList& group_members);
void initUsersData(std::string folder_path, CQUserDataList& users_data);

#endif // !ALPHA_INITS_H
