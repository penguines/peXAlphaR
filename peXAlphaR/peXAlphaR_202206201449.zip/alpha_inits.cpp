#include "alpha_inits.h"

CQGroupMemberData::CQGroupMemberData(){
	this->group_id = "";
}

CQGroupMemberData::~CQGroupMemberData() {

}

// �������ļ���\\data\\groups\\Ⱥ��\\global.json
//								 \\[user_id].json
void initGroupsData(std::string folder_path, CQGroupList& groups, CQGrpMbrDataList& group_members) {
	std::vector<std::string> sub_folders, member_files;
	getSubFolders(folder_path, sub_folders);
	for (int i = 0; i < sub_folders.size(); i++) {
		groups.emplace_back();
		groups[i].id = sub_folders[i];
		jsonFile& json_file_tmp = groups[i].group_data;
		json_file_tmp.file_path = folder_path + sub_folders[i] + "\\";
		json_file_tmp.file_name = GROUP_DATA_FILE_NAME;
		json_file_tmp.identifier = sub_folders[i];
		json_file_tmp.load();

		getFilesB(json_file_tmp.file_path, member_files);
		group_members.emplace_back();
		CQGroupMemberData& grpmbr_tmp = group_members[i];
		int cnt_tmp = 0;
		grpmbr_tmp.group_id = sub_folders[i];
		for (int j = 0; j < member_files.size(); j++) {
			if (member_files[j] != GROUP_DATA_FILE_NAME) {
				grpmbr_tmp.members_data.emplace_back();
				grpmbr_tmp.members_data[cnt_tmp].file_path = json_file_tmp.file_path;
				grpmbr_tmp.members_data[cnt_tmp].file_name =  member_files[j];
				getFileName(member_files[j], grpmbr_tmp.members_data[cnt_tmp].identifier);
				grpmbr_tmp.members_data[cnt_tmp].load();
				cnt_tmp++;
			}
		}
		member_files.clear();
	}
}

// �������ļ���\\data\\users\\[user_id].json

void initUsersData(std::string folder_path, CQUserDataList& users_data){
	std::vector<std::string> user_files;
	getFilesB(folder_path, user_files);
	for (int i = 0; i < user_files.size(); i++) {
		users_data.emplace_back();
		jsonFile& json_file_tmp = users_data[i];
		json_file_tmp.file_path = folder_path;
		json_file_tmp.file_name = user_files[i];
		getFileName(user_files[i], json_file_tmp.identifier);
		json_file_tmp.load();
	}
}

