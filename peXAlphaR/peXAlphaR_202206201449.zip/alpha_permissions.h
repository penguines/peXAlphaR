#ifndef ALPHA_PERMISSIONS_H
#define ALPHA_PERMISSIONS_H

#include <string>
#include "cq_api_post.h"
#include "cq_msg.h"
#include "cq_event.h"
#include "json_file.h"

#define DEFAULT_PERMISSION_LEVEL 1
#define PERMISSION_ACCEPTED ""
#define PERMISSION_DENIED	"����Ȩ�޲�����ʹ�ñ����"
#define PERMISSION_UNEXISTED "�û���ϢΪ�գ��޷���ѯȨ�޵ȼ�����ִ�У��ܾ���"

namespace alpha_permission {
	void setBotOwner(std::string id);
	void setUserData(std::vector<jsonFile>& user_data);
}

int checkPermissionLevel(int user_permission_level, int required_permission_level, std::string& response_msg);
int checkPermissionLevel(CQGroupMsg& group_msg, int required_permission_level);

int setOperator(CQmsg& msg);
void register_setOperator(std::vector<CQEvent>& event_list);

int delOperator(CQmsg& msg);
void register_delOperator(std::vector<CQEvent>& event_list);

#endif // !ALPHA_PERMISSIONS_H
