#include "load_from_json.h"

int loadStringByKeyword(std::string keyword, Json::Value& json, std::string& str_dst) {
	if (json.isMember(keyword)) {
		str_dst = json[keyword].asString();
		return 1;
	}
	else {
		str_dst.clear();
		return 0;
	}
}

int loadIntByKeyword(std::string keyword, Json::Value& json, int& int_dst){
	if (json.isNull()) {
		return 0;
	}
	if (json.isMember(keyword) && json[keyword].isInt()) {
		int_dst = json[keyword].asInt();
		return 1;
	}
	else {
		return 0;
	}
}
