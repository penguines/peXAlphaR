#include "alpha_runtime.h"

static std::string GROUP_DATA_FOLDER;
static std::string USER_DATA_FOLDER;

void setGroupDataFolder(std::string folder_path){
	GROUP_DATA_FOLDER = folder_path;
}

void setUserDataFolder(std::string folder_path){
	USER_DATA_FOLDER = folder_path;
}

void loadCQUserData(CQuser& user, CQUserDataList& user_data){
	for (int i = 0; i < user_data.size(); i++) {
		if (user_data[i].identifier == user.id) {
			user.customed_user_data = &(user_data[i]);
			return;
		}
	}
	if (!USER_DATA_FOLDER.empty()) {
		createNewCQUserData(user_data, user.id);
		user.customed_user_data = &(user_data.back());
	}
}

void loadCQmsgUserData(CQPrivateMsg& msg, CQUserDataList& user_data){
	loadCQUserData(*(msg.sender), user_data);
}

void loadCQmsgUserData(CQGroupMsg& msg, CQUserDataList& user_data){
	loadCQUserData(*(msg.sender), user_data);
}

void loadCQmsgGroupData(CQGroupMsg& msg, CQGroupList& groups_data, CQGrpMbrDataList& groups_member_data){
	for (int i = 0; i < groups_member_data.size(); i++) {
		if (groups_member_data[i].group_id == msg.group->id) {
			msg.group = &(groups_data[i]);
			jsonFileList& members = groups_member_data[i].members_data;
			for (int j = 0; j < members.size(); j++) {
				if (members[j].identifier == msg.sender->id) {
					msg.sender->customed_grpmbr_data = &(members[j]);
					return;
				}
			}
			createNewCQGrpmbrData(groups_member_data[i], msg.sender->id);
			msg.sender->customed_grpmbr_data = &(groups_member_data[i].members_data.back());
			return;
		}
	}
	if (!GROUP_DATA_FOLDER.empty()) {
		if(createNewCQGroupData(groups_data, msg.group->id)){
			groups_member_data.emplace_back();
			CQGroupMemberData& new_data_tmp = groups_member_data.back();
			new_data_tmp.group_id = msg.group->id;
			createNewCQGrpmbrData(new_data_tmp, msg.sender->id);
			msg.sender->customed_grpmbr_data = &(new_data_tmp.members_data.back());
		}
	}
}

void createNewCQUserData(CQUserDataList& user_data, std::string user_id){
	user_data.emplace_back();
	jsonFile& new_user_data = user_data.back();
	new_user_data.file_path = USER_DATA_FOLDER;
	new_user_data.file_name = user_id + ".json";
	new_user_data.identifier = user_id;
	new_user_data.json["user_id"] = user_id;
	//customed data
	new_user_data.json["is_operator"] = 0;
	/*
		Other data here...
	*/
	new_user_data.save();
}

void createNewCQGrpmbrData(CQGroupMemberData& group_member_data, std::string user_id){
	group_member_data.members_data.emplace_back();
	jsonFile& new_member_data = group_member_data.members_data.back();
	new_member_data.file_path = GROUP_DATA_FOLDER + group_member_data.group_id + "\\";
	new_member_data.file_name = user_id + ".json";
	new_member_data.identifier = user_id;
	new_member_data.json["user_id"] = user_id;
	//customed data
	new_member_data.json["permission"] = DEFAULT_PERMISSION_LEVEL;
	/*
		Other data here...
	*/
	new_member_data.save();
}

int createNewCQGroupData(CQGroupList& group_list, std::string group_id){
	if (createFolder(GROUP_DATA_FOLDER + group_id + "\\") == 0) {
		group_list.emplace_back();
		jsonFile& new_group_data = group_list.back().group_data;
		new_group_data.file_path = GROUP_DATA_FOLDER + group_id + "\\";
		new_group_data.file_name = GROUP_DATA_FILE_NAME;
		new_group_data.identifier = group_id;
		new_group_data.json["group_id"] = group_id;
		//customed data
		new_group_data.json["repeat"] = DEFAULT_REPEAT_TIMES;
		/*
			Other data here...
		*/
		new_group_data.save();
		return 1;
	}
	else {
		return 0;
	}
}
