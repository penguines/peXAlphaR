#include "alpha_basic_event.h"

using namespace CQJmsg;

static std::string img_folder;
static std::string img_folder_f;
static std::string sauce_api_key;

static size_t req_reply(void* ptr, size_t size, size_t nmemb, void* stream) {
	std::string* str = (std::string*)stream;
	(*str).append((char*)ptr, size * nmemb);
	return size * nmemb;
}

int dailySignIn(CQmsg& msg) {
	CQGroupMsg& group_msg = (CQGroupMsg&)msg;
	if (!checkPermissionLevel(group_msg, ALPHA_DAILY_SINGIN_PERMISSION)) {
		return 0;
	}
	pJsonFile_t data_tmp = group_msg.sender->customed_user_data;
	if (data_tmp == nullptr) {
		return 0;
	}
	time_t time_tmp;
	CQJsonMsg signMsg;
	int last_signed = 0;
	int cur_date = 0;
	int cur_signs = 0;
	int cur_continuous_sign = 0;
	int max_continuous_sign = 0;
	time(&time_tmp);
	time_tmp += 3600 * 8;
	cur_date = time_tmp / 86400;

	signMsg += CQJmsg::at(group_msg.sender->id);
	if (!loadIntByKeyword("last_signed", data_tmp->json, last_signed)) {
		data_tmp->json["last_signed"] = cur_date;
		data_tmp->json["cur_signs"] = 1;
		data_tmp->json["cur_continuous_signs"] = 1;
		data_tmp->json["max_continuous_signs"] = 1;
		data_tmp->save();
		signMsg += GB2312ToUTF8(" ��_��");
		sendGroupMsg(group_msg.group->id, signMsg.getJson());
		return 1;
	}
	else {
		if (cur_date != last_signed) {
			loadIntByKeyword("cur_signs", data_tmp->json, cur_signs, 1);
			loadIntByKeyword("cur_continuous_signs", data_tmp->json, cur_continuous_sign, 1);
			loadIntByKeyword("max_continuous_signs", data_tmp->json, max_continuous_sign, 1);
			cur_signs++;
			data_tmp->json["cur_signs"] = cur_signs;
			if (cur_date == last_signed + 1) {
				cur_continuous_sign++;
			}
			else {
				cur_continuous_sign = 1;
			}
			data_tmp->json["cur_continuous_signs"] = cur_continuous_sign;

			if (cur_continuous_sign > max_continuous_sign) {
				max_continuous_sign = cur_continuous_sign;
				data_tmp->json["max_continuous_signs"] = max_continuous_sign;
			}
			data_tmp->json["last_signed"] = cur_date;
			data_tmp->save();
			std::string signs_tmp("����ǰ����ǩ������: ");
			signs_tmp.append(std::to_string(cur_continuous_sign)).append("��\n���������ǩ������: ");
			signs_tmp.append(std::to_string(max_continuous_sign)).append("��\n����ǩ������: ");
			signs_tmp.append(std::to_string(cur_signs)).append("��");
			signMsg += " ǩ�ϵ���������";
			signMsg += CQJmsg::image(img_folder_f + ALPHA_SIGN_IMG_1);
			signMsg += signs_tmp;
			signMsg.textToUTF8();
			sendGroupMsg(group_msg.group->id, signMsg.getJson());
			return 1;
		}
		else {
			signMsg += " �������Ѿ�ǩ������...";
			signMsg += CQJmsg::image(img_folder_f + ALPHA_SIGN_IMG_2);
			signMsg.textToUTF8();
			sendGroupMsg(group_msg.group->id, signMsg.getJson());
			return 0;
		}
	}
	return 0;
}

void register_dailySignIn(std::vector<CQEvent>& event_list) {
	CQEvent event_tmp;
	event_tmp.event_func = dailySignIn;
	event_tmp.event_type = EVENT_GROUP;
	event_tmp.trig_type = MSG_MATCH;
	event_tmp.trig_msg.emplace_back("ǩ��");
	event_tmp.trig_msg.emplace_back("/ǩ��");
	event_tmp.trig_msg.emplace_back("#ǩ��");
	event_tmp.msg_codetype = CODE_UTF8;
	//Event tag
	event_tmp.tag.index = 0;
	event_tmp.tag.permission = ALPHA_DAILY_SINGIN_PERMISSION;
	event_tmp.tag.name = "ÿ��ǩ��";
	event_tmp.tag.example = "ǩ��(/ǩ��;#ǩ��)";
	event_tmp.tag.description = "ÿ��ǩ����";

	event_list.push_back(event_tmp);
}


int atSB(CQmsg& msg) {
	CQGroupMsg* group_msg = (CQGroupMsg*)&msg;
	CQJsonMsg jmsg_tmp;
	jmsg_tmp.append(at(group_msg->sender->id)).append(image(img_folder_f + "atsb.jpg"));
	sendGroupMsg(group_msg->group->id, jmsg_tmp.getJson());
	return 0;
}

int condition_atSB(CQmsg& msg) {
	std::string str_tmp;
	if (!msg.content.isArray()) {
		return 0;
	}
	for (int i = 0; i < msg.content.size(); i++) {
		loadStringByKeyword("type", msg.content[i], str_tmp);
		if (str_tmp == "at") {
			if (msg.content[i].isMember("data")) {
				loadStringByKeyword("qq", msg.content[i]["data"], str_tmp);
				if (str_tmp == msg.self_id) {
					return 1;
				}
			}
		}
	}
	return 0;
}

void register_atSB(std::vector<CQEvent>& event_list) {
	CQEvent event_tmp;
	event_tmp.event_func = atSB;
	event_tmp.event_type = EVENT_GROUP;
	event_tmp.custom_condition = condition_atSB;
	event_tmp.trig_type = TRIG_CUSTOMIZE;
	event_tmp.msg_codetype = CODE_UTF8;
	event_tmp.tag.index = 0;
	event_tmp.tag.name = "atsb";

	event_list.push_back(event_tmp);
}


void imageSearch(const std::string& img_url, std::string& response) {
	static const std::string post_url = "https://saucenao.com/search.php?";
	static std::string post_full_url = post_url + "output_type=2&numres=1&minsim=80!&dbmask=8191&api_key=" + sauce_api_key;

	std::string m_data = "-----------------------------54382956620782\n"
		"Content-Disposition: form-data; name=\"file\"; filename=\"\"\n"
		"Content-Type: application/octet-stream\n"
		"\n"
		"\n"
		"-----------------------------54382956620782\n"
		"Content-Disposition: form-data; name=\"url\"\n"
		"\n";
	m_data += img_url + "\n";
	m_data += "-----------------------------54382956620782\n"
		"Content-Disposition: form-data; name=\"frame\"\n"
		"\n"
		"1\n"
		"-----------------------------54382956620782\n"
		"Content-Disposition: form-data; name=\"hide\"\n"
		"\n"
		"0\n"
		"-----------------------------54382956620782\n"
		"Content-Disposition: form-data; name=\"database\"\n"
		"\n"
		"999\n"
		"-----------------------------54382956620782--\n";

	CURL* curl = curl_easy_init();
	// res code  
	CURLcode res;
	struct curl_slist* headers = NULL;
	struct curl_httppost* postdata = NULL;
	struct curl_httppost* postdataLst = NULL;
	headers = curl_slist_append(headers, "Host: saucenao.com");
	headers = curl_slist_append(headers, "Content-Type: multipart/form-data; boundary=---------------------------54382956620782");
	if (curl) {
		// set params  
		curl_easy_setopt(curl, CURLOPT_POST, 1L); // post req  
		curl_easy_setopt(curl, CURLOPT_URL, post_full_url.c_str()); // url  
		curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
		//curl_easy_setopt(curl, CURLOPT_HTTPPOST, postdata);
		curl_easy_setopt(curl, CURLOPT_POSTFIELDS, m_data.c_str()); // params  
		curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, false); // if want to use https  
		curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, false); // set peer and host verify false  
		curl_easy_setopt(curl, CURLOPT_VERBOSE, 1);
		curl_easy_setopt(curl, CURLOPT_READFUNCTION, NULL);
		curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, req_reply);
		curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void*)&response);
		// start req  
		res = curl_easy_perform(curl);
		//std::cout << utf8ToGB2312(response) << std::endl;
	}
	// release curl  
	curl_easy_cleanup(curl);
}

void imageSearchProc(std::string image_url, std::string reply_id, std::string at_id, int msg_type) {
	CQJsonMsg result_msg;
	std::string result_msg_str;
	std::string search_result;
	std::string img_sim, img_url, img_src, img_artist, img_artist_id;
	std::string img_title, img_src_url, img_id;

	imageSearch(image_url, search_result);
	if (search_result.empty()) {
		if (msg_type == MSG_GROUP) {
			sendGroupMsg(reply_id, "��ͼ����������Ӧ��");
		}
		else {
			sendPrivateMsg(reply_id, "��ͼ����������Ӧ��");
		}
		return;
	}

	imgSearchAnsJson(search_result,
		img_sim,
		img_url,
		img_src,
		img_artist,
		img_artist_id,
		img_title,
		img_src_url,
		img_id);

	if (!img_url.empty()) {
		result_msg_str.append(GB2312ToUTF8("\n���ƶ�: ")).append(img_sim).append("\%");
		result_msg_str.append(GB2312ToUTF8("\n��Դ: ")).append(img_src);
		result_msg_str.append(GB2312ToUTF8("\n����: ")).append(img_title);
		result_msg_str.append(GB2312ToUTF8("\n����: ")).append(img_artist);
		result_msg_str.append(GB2312ToUTF8("\n����id: ")).append(img_artist_id);
		result_msg_str.append(GB2312ToUTF8("\nͼƬid: ")).append(img_id);
		result_msg_str.append(GB2312ToUTF8("\nͼƬ����: ")).append(img_src_url);
		result_msg_str.append("\n[SauceNAO]");

		result_msg += CQJmsg::at(at_id);
		result_msg += GB2312ToUTF8(" �������:\n");
		result_msg += CQJmsg::image(img_url);
		result_msg += result_msg_str;
	}
	else {
		result_msg += CQJmsg::at(at_id);
		result_msg += GB2312ToUTF8("δ�ҵ�����ͼƬ��");
	}

	if (msg_type == MSG_GROUP) {
		sendGroupMsg(reply_id, result_msg.getJson());
	}
	else {
		sendPrivateMsg(reply_id, result_msg.getJson());
	}
}

void imgSearchAnsJson(const std::string& resultJson,
	std::string& similarity,
	std::string& imgUrl,
	std::string& src,
	std::string& artist,
	std::string& artist_id,
	std::string& title,
	std::string& srcUrl,
	std::string& imgId)
{
	Json::Reader rd;
	Json::Value result, resultHeader, resultData;
	double simtmp;
	if (rd.parse(resultJson, result)) {
		resultHeader = result["results"][0]["header"];
		resultData = result["results"][0]["data"];
		similarity = resultHeader["similarity"].asString();
		simtmp = atof(similarity.c_str());
		if (simtmp < 40) {
			imgUrl = "";
			return;
		}
		imgUrl = resultHeader["thumbnail"].asString();
		srcUrl = resultData["ext_urls"][0].asString();
		if (resultData.isMember("title")) title = resultData["title"].asString();
		else title = resultData["characters"].asString();
		if (resultData.isMember("member_id")) {
			artist_id = resultData["member_id"].asString();
			artist = resultData["member_name"].asString();
			if (resultData.isMember("pixiv_id")) {
				src = "Pixiv";
				imgId = resultData["pixiv_id"].asString();
			}
			else {
				src = "Seiga";
				imgId = resultData["pixiv_id"].asString();
			}
		}
		else if (resultData.isMember("creator")) {
			artist = resultData["creator"].asString();
			srcUrl = resultData["source"].asString();
			if (resultData.isMember("danbooru_id")) {
				src = "Danbooru";
				imgId = resultData["danbooru_id"].asString();
			}
		}
	}
}

int imgSearch(CQmsg& msg) {
	if (sauce_api_key.empty()) {
		PRINTLOG("�޷���ͼ: ��SauceNAO API key.");
		return 0;
	}
	if (!checkPermission(msg, ALPHA_IMGSEARCH_PERMISSION)) {
		return 0;
	}

	const Json::Value& tmp = msg.content;
	std::string str_tmp;
	int cnt = 0;
	if (tmp.isArray()) {
		for (int i = 0; i < tmp.size(); i++) {
			loadStringByKeyword("type", tmp[i], str_tmp);
			if (str_tmp == "image") {
				if (!tmp[i].isMember("data")) {
					continue;
				}
				loadStringByKeyword("url", tmp[i]["data"], str_tmp);
				std::thread thread_tmp(imageSearchProc, str_tmp, getMsgReplyID(msg), getMsgSenderID(msg), msg.msg_type);
				thread_tmp.detach();
				cnt++;
			}
		}
	}
	if (cnt) {
		sendReply(msg, "��������" + std::to_string(cnt) + "��ͼƬ����", 0);
		return 1;
	}
	else {
		sendReply(msg, "��ë��", 0);
		return 0;
	}
}

void register_imgSearch(std::vector<CQEvent>& event_list) {
	CQEvent event_tmp;
	event_tmp.event_func = imgSearch;
	event_tmp.event_type = EVENT_ALL;
	event_tmp.trig_type = MSG_MATCH;
	event_tmp.trig_msg.emplace_back("��ͼ");
	event_tmp.trig_msg.emplace_back("/��ͼ");
	event_tmp.trig_msg.emplace_back("#��ͼ");
	event_tmp.msg_codetype = CODE_UTF8;
	event_tmp.tag.index = 0;
	event_tmp.tag.name = "��ͼ";
	event_tmp.tag.permission = ALPHA_IMGSEARCH_PERMISSION;
	event_tmp.tag.example = "��ͼ[ͼƬ]";
	event_tmp.tag.description = "����SauceNAO��������ָ��ͼƬ��";

	event_list.push_back(event_tmp);
}

void alpha_basicEvents::setImgFolder(const std::string& path) {
	img_folder = path;
	img_folder_f = "file:///" + img_folder;
}

void alpha_basicEvents::setSauceNAO(const std::string& api_key) {
	sauce_api_key = api_key;
}
