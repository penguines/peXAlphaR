#ifndef ALPHA_BASIC_EVENT_H
#define ALPHA_BASIC_EVENT_H

#include <time.h>
#include <thread>
#include <curl/curl.h>
#include "cq_event.h"
#include "json_file.h"
#include "cq_json_msg.h"
#include "alpha_debug.h"
#include "alpha_permissions.h"

#define ALPHA_DAILY_SINGIN_PERMISSION 0
#define ALPHA_SIGN_IMG_1 "sign1.jpg"
#define ALPHA_SIGN_IMG_2 "sign2.jpg"

#define ALPHA_IMGSEARCH_PERMISSION 0

namespace alpha_basicEvents {
	void setImgFolder(const std::string& path);
	void setSauceNAO(const std::string& api_key);
}

int dailySignIn(CQmsg& msg);
void register_dailySignIn(std::vector<CQEvent>& event_list);

int atSB(CQmsg& msg);
int condition_atSB(CQmsg& msg);
void register_atSB(std::vector<CQEvent>& event_list);

void imageSearch(const std::string& img_url, std::string& response);
void imageSearchProc(std::string image_url, std::string reply_id, std::string at_id, int msg_type);
void imgSearchAnsJson(const std::string& resultJson,
					std::string& similarity,
					std::string& imgUrl,
					std::string& src,
					std::string& artist,
					std::string& artist_id,
					std::string& title,
					std::string& srcUrl,
					std::string& imgId);

int imgSearch(CQmsg& msg);
void register_imgSearch(std::vector<CQEvent>& event_list);

#endif // !ALPHA_BASIC_EVENT_H
