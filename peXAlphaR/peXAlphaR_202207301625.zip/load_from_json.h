#ifndef LOAD_FROM_JSON_H
#define LOAD_FROM_JSON_H

#include <string>
#include <json/json.h>

int loadStringByKeyword(std::string keyword,
						const Json::Value& json,
						std::string& str_dst);

int loadStringByKeyword(std::string keyword,
						Json::Value& json,
						std::string& str_dst,
						const char* default_str);

int loadIntByKeyword(std::string keyword,
					 const Json::Value& json,
					 int& int_dst);

int loadIntByKeyword(std::string keyword,
				  	 Json::Value& json,
					 int& int_dst,
					 int default_int);

#endif // !LOAD_FROM_JSON_H
