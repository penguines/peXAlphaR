#include "cq_group.h"

CQgroup::CQgroup(){
	this->id = "";
}

CQgroup::CQgroup(Json::Value& group){
	this->load(group);
}

CQgroup::~CQgroup(){
	this->id.clear();
	this->group_data.clear();
}

void CQgroup::load(Json::Value& group){
	this->loadID(group);
}

void CQgroup::clear(){
	this->id = "";
	this->group_data.clear();
}

void CQgroup::loadID(Json::Value& group){
	loadStringByKeyword("group_id", group, this->id);
}