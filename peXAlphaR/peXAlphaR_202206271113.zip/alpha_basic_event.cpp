#include "alpha_basic_event.h"

int dailySignIn(CQmsg& msg){
	CQGroupMsg& group_msg = (CQGroupMsg&)msg;
	if (!checkPermissionLevel(group_msg, ALPHA_DAILY_SINGIN_PERMISSION)) {
		return 0;
	}
	pJsonFile_t data_tmp = group_msg.sender->customed_user_data;
	if (data_tmp == nullptr) {
		return 0;
	}
	time_t time_tmp;
	CQJsonMsg signMsg;
	int last_signed = 0;
	int cur_date = 0;
	int cur_signs = 0;
	int cur_continuous_sign = 0;
	int max_continuous_sign = 0;
	time(&time_tmp);
	cur_date = time_tmp / 86400;

	signMsg += CQJmsg::at(group_msg.sender->id);
	if (!loadIntByKeyword("last_signed", data_tmp->json, last_signed)) {
		data_tmp->json["last_signed"] = cur_date;
		data_tmp->json["cur_signs"] = 1;
		data_tmp->json["cur_continuous_signs"] = 1;
		data_tmp->json["max_continuous_signs"] = 1;
		data_tmp->save();
		signMsg += GB2312ToUTF8(" ��_��");
		sendGroupMsg(group_msg.group->id, signMsg.getJson());
		return 1;
	}
	else {
		if (cur_date != last_signed) {
			loadIntByKeyword("cur_signs", data_tmp->json, cur_signs, 1);
			loadIntByKeyword("cur_continuous_signs", data_tmp->json, cur_continuous_sign, 1);
			loadIntByKeyword("max_continuous_signs", data_tmp->json, max_continuous_sign, 1);
			cur_signs++;
			data_tmp->json["cur_signs"] = cur_signs;
			if (cur_date == last_signed + 1) {
				cur_continuous_sign++;
			}
			else {
				cur_continuous_sign = 1;
			}
			data_tmp->json["cur_continuous_signs"] = cur_continuous_sign;
			
			if (cur_continuous_sign > max_continuous_sign) {
				max_continuous_sign = cur_continuous_sign;
				data_tmp->json["max_continuous_signs"] = max_continuous_sign;
			}
			data_tmp->json["last_signed"] = cur_date;
			data_tmp->save();
			signMsg += " ǩ�ϵ���������";
			signMsg += CQJmsg::image(ALPHA_SIGN_IMG_1);
			signMsg.textToUTF8();
			sendGroupMsg(group_msg.group->id, signMsg.getJson());
			return 1;
		}
		else {
			signMsg += " �������Ѿ�ǩ������...";
			signMsg += CQJmsg::image(ALPHA_SIGN_IMG_2);
			signMsg.textToUTF8();
			sendGroupMsg(group_msg.group->id, signMsg.getJson());
			return 0;
		}
	}
	return 0;
}

void register_dailySignIn(std::vector<CQEvent>& event_list){
	CQEvent event_tmp;
	event_tmp.event_func = dailySignIn;
	event_tmp.event_type = EVENT_GROUP;
	event_tmp.trig_type = MSG_MATCH;
	event_tmp.trig_msg.emplace_back("ǩ��");
	event_tmp.trig_msg.emplace_back("/ǩ��");
	event_tmp.trig_msg.emplace_back("#ǩ��");
	event_tmp.msg_codetype = CODE_UTF8;
	//Event tag
	event_tmp.tag.index = 0;
	event_tmp.tag.permission = ALPHA_DAILY_SINGIN_PERMISSION;
	event_tmp.tag.name = "ÿ��ǩ��";
	event_tmp.tag.example = "ǩ��(/ǩ��;#ǩ��)";
	event_tmp.tag.description = "ÿ��ǩ����";

	event_list.push_back(event_tmp);
}
