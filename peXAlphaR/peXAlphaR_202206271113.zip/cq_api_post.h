#ifndef CQ_API_POST_H
#define CQ_API_POST_H

#include <iostream>
#include <string>
#include <vector>
#include <WinSock2.h>
#include <windows.h>
#include "cq_transcoder.h"
#include "cq_msg.h"

#define ALPHA_POST_WITH_JSON

namespace cq_post_api {
	void setPostIP(std::string host = "127.0.0.1", int port = 5700);
}

#ifndef ALPHA_POST_WITH_JSON
//previous API
void sendHttpData(std::string, char*, int);

#else

void sendGroupMsg(std::string group_id, const Json::Value& json);
void sendPrivateMsg(std::string group_id, const Json::Value& json);
void sendReply(CQmsg& msg, const Json::Value& json);

#endif

//latest API
std::string sendCommand(std::string command);

void sendGroupMsg(std::string group_id, std::string msg, int isUTF8);
void sendPrivateMsg(std::string id, std::string msg, int isUTF8);
void sendReply(CQmsg& msg, std::string reply, int isUTF8);

#endif
