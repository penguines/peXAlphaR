#ifndef EVENT_REGISTER_H
#define EVENT_REGISTER_H

#include <vector>
#include "cq_event.h"

typedef std::vector<CQEvent> eventList;
typedef std::vector<void(*)(eventList&)> registerFuncList;

class eventRegister {
public:
	eventRegister();
	virtual ~eventRegister();

	void append(void (*reg_func)(eventList&));
	int registerEvents();
	int executeEvents(CQmsg& msg);
	size_t eventSize();
	int generateHelp(std::string& help_str,
					 int max_permission = INT_MAX,
					 int event_type = EVENT_ALL);
	eventList& getEvents();
private:
	eventList m_events;
	registerFuncList m_regfuncs;
};

#endif // !EVENT_REGISTER_H
