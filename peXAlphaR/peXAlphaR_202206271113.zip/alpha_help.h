#ifndef ALPHA_HELP_H
#define ALPHA_HELP_H

#include "cq_api_post.h"
#include "event_register.h"
#include "alpha_permissions.h"

#define GET_HELP_PERMISSION_LEVEL 0

namespace alpha_help {
	void setEventRegister(eventRegister& event_reg);
	void setOwnerID(std::string& id);
};

int getHelp(CQmsg& msg);
void register_getHelp(std::vector<CQEvent>& event_list);

int searchHelp(CQmsg& msg);
void register_searchHelp(std::vector<CQEvent>& event_list);

#endif // !ALPHA_HELP_H
