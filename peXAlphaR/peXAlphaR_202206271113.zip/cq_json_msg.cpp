#include "cq_json_msg.h"

CQJsonMsg::CQJsonMsg(){
	this->m_json.clear();
}

CQJsonMsg::CQJsonMsg(std::string text){
	this->append(text);
}

CQJsonMsg::CQJsonMsg(std::string type, std::string data_key, std::string data_value){
	static Json::Value json_msg_tmp;
	static bool is_init = false;
	if (is_init == false) {
		json_msg_tmp["type"] = type;
		json_msg_tmp["data"][data_key] = "";
		is_init = true;
	}
	json_msg_tmp["data"][data_key] = data_value;
	this->m_json.append(json_msg_tmp);
}

CQJsonMsg::~CQJsonMsg(){

}

CQJsonMsg& CQJsonMsg::operator=(std::string text){
	this->m_json.clear();
	return this->append(text);
}

CQJsonMsg& CQJsonMsg::operator=(const char* text){
	this->m_json.clear();
	return this->append(text);
}

CQJsonMsg& CQJsonMsg::operator=(const CQJsonMsg& json_msg){
	if (this == &json_msg) {
		return *this;
	}
	this->m_json.clear();
	this->m_json.copy(json_msg.getJson());
	return *this;
}

CQJsonMsg& CQJsonMsg::operator=(const Json::Value& json){
	this->m_json.clear();
	this->m_json.append(json);
	return *this;
}

CQJsonMsg& CQJsonMsg::operator+(std::string text){
	return this->append(text);
}

CQJsonMsg& CQJsonMsg::operator+(const char* text){
	return this->append(text);
}

CQJsonMsg& CQJsonMsg::operator+(const CQJsonMsg& json_msg){
	return this->append(json_msg);
}

CQJsonMsg& CQJsonMsg::operator+(const Json::Value& json){
	return this->append(json);
}

CQJsonMsg& CQJsonMsg::operator+=(std::string text){
	return this->append(text);
}

CQJsonMsg& CQJsonMsg::operator+=(const char* text){
	return this->append(text);
}

CQJsonMsg& CQJsonMsg::operator+=(const CQJsonMsg& json_msg){
	return this->append(json_msg);
}

CQJsonMsg& CQJsonMsg::operator+=(const Json::Value& json){
	return this->append(json);
}

CQJsonMsg& CQJsonMsg::append(std::string text){
	return this->append(text.c_str());
}

CQJsonMsg& CQJsonMsg::append(const char* text){
	static Json::Value json_text_tmp;
	static bool is_init = false;
	if (is_init == false) {
		json_text_tmp["type"] = "text";
		json_text_tmp["data"]["text"] = "";
		is_init = true;
	}
	json_text_tmp["data"]["text"] = text;
	this->m_json.append(json_text_tmp);
	return *this;
}

CQJsonMsg& CQJsonMsg::append(const CQJsonMsg& json_msg){
	const Json::Value& json_tmp = json_msg.getJson();
	int sz = 0;
	if (!json_tmp.empty()) {
		sz = json_tmp.size();
		for (int i = 0; i < sz; i++) {
			this->m_json.append(json_tmp[i]);
		}
	}
	return *this;
}

CQJsonMsg& CQJsonMsg::append(const Json::Value& json){
	if (!json.empty()) {
		this->m_json.append(json);
	}
	return *this;
}

void CQJsonMsg::clear(){
	this->m_json.clear();
}

void CQJsonMsg::textToUTF8(){
	if (this->m_json.empty()) {
		return;
	}
	std::string text_tmp;
	for (int i = 0; i < this->m_json.size(); i++) {
		loadStringByKeyword("type", m_json[i], text_tmp);
		if (text_tmp == "text") {
			Json::Value& json_tmp = m_json[i]["data"];
			loadStringByKeyword("text", json_tmp, text_tmp);
			text_tmp = GB2312ToUTF8(text_tmp);
			m_json[i]["data"]["text"] = text_tmp;
		}
	}
}

const Json::Value& CQJsonMsg::getJson() const{
	return static_cast<const Json::Value&>(this->m_json);
}

const Json::Value& CQJmsg::at(std::string user_id){
	static Json::Value json_at_tmp;
	static bool is_init = false;
	if (is_init == false) {
		json_at_tmp["type"] = "at";
		json_at_tmp["data"]["qq"] = "";
		is_init = true;
	}
	json_at_tmp["data"]["qq"] = user_id;
	return json_at_tmp;
}

const Json::Value& CQJmsg::image(std::string img_full_path){
	static Json::Value json_img_tmp;
	static bool is_init = false;
	if (is_init == false) {
		json_img_tmp["type"] = "image";
		json_img_tmp["data"]["file"] = "";
		is_init = true;
	}
	json_img_tmp["data"]["file"] = img_full_path;
	return json_img_tmp;
}
