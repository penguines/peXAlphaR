#ifndef CQ_JSON_MSG_H
#define CQ_JSON_MSG_H

#include <string>
#include <json/json.h>
#include "load_from_json.h"
#include "cq_transcoder.h"

class CQJsonMsg {
public:
	CQJsonMsg();
	CQJsonMsg(std::string text);
	CQJsonMsg(std::string type, std::string data_key, std::string data_value);
	virtual ~CQJsonMsg();

	CQJsonMsg& operator=(std::string text);
	CQJsonMsg& operator=(const char* text);
	CQJsonMsg& operator=(const CQJsonMsg& json_msg);
	CQJsonMsg& operator=(const Json::Value& json);

	CQJsonMsg& operator+(std::string text);
	CQJsonMsg& operator+(const char* text);
	CQJsonMsg& operator+(const CQJsonMsg& json_msg);
	CQJsonMsg& operator+(const Json::Value& json);

	CQJsonMsg& operator+=(std::string text);
	CQJsonMsg& operator+=(const char* text);
	CQJsonMsg& operator+=(const CQJsonMsg& json_msg);
	CQJsonMsg& operator+=(const Json::Value& json);

	CQJsonMsg& append(std::string text);
	CQJsonMsg& append(const char* text);
	CQJsonMsg& append(const CQJsonMsg& json_msg);
	CQJsonMsg& append(const Json::Value& json);

	void clear();
	void textToUTF8();
	const Json::Value& getJson() const;
private:
	Json::Value m_json;
};

namespace CQJmsg {
	const Json::Value& at(std::string user_id);
	const Json::Value& image(std::string img_full_path);
};

#endif