#ifndef ALPHA_BASIC_EVENT_H
#define ALPHA_BASIC_EVENT_H

#include <time.h>
#include "cq_event.h"
#include "json_file.h"
#include "cq_json_msg.h"
#include "alpha_permissions.h"

#define ALPHA_DAILY_SINGIN_PERMISSION 0
#define ALPHA_SIGN_IMG_1 "file:///F:/peXAlpha_Reborn/sign1.jpg"
#define ALPHA_SIGN_IMG_2 "file:///F:/peXAlpha_Reborn/sign2.jpg"

int dailySignIn(CQmsg& msg);
void register_dailySignIn(std::vector<CQEvent>& event_list);



#endif // !ALPHA_BASIC_EVENT_H
