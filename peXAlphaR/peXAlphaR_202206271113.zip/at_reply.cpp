#include "at_reply.h"

using namespace CQJmsg;

void sendTest(Json::Value& json_msg) {
		struct hostent* p_hostent = gethostbyname("127.0.0.1");
		if (p_hostent == NULL) {
			return;
		}
		sockaddr_in addr_server;
		addr_server.sin_family = AF_INET;
		addr_server.sin_addr.s_addr = inet_addr("127.0.0.1");
		addr_server.sin_port = htons(5700);
		memcpy(&(addr_server.sin_addr), p_hostent->h_addr_list[0], sizeof(addr_server.sin_addr));
		int sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
		int res = connect(sock, (sockaddr*)&addr_server, sizeof(addr_server));
		if (res == -1) {
#ifdef ALPHA_SHOW_ALL_INFO
			std::cout << "Connect failed " << std::endl;
#endif
			closesocket(sock);
			return;
		}
		std::string payload = "{\"type\":\"text\",\"data\":{\"text\":\"�Ҵ����Ǵ�\"}}";
		std::string sendData = "GET /send_group_msg?group_id=109336271 HTTP/1.1\r\n";
		sendData += "Host:127.0.0.1\r\n";
		sendData += "Content-Type:application/json\r\n";
		sendData += "Content-Length:" + std::to_string(payload.length()) + "\r\n";
		sendData += "\n\n";
		//sendData += json_msg.toStyledString();
		sendData += payload;
		sendData += "\r\n\r\n";
		send(sock, sendData.c_str(), sendData.size(), 0);
		std::string  m_readBuffer;
		if (m_readBuffer.empty()) {
			m_readBuffer.resize(32767);
		}
		int readCount = recv(sock, &m_readBuffer[0], m_readBuffer.size(), 0);
		std::cout << "Request: " << sendData.c_str() << " and response:" << m_readBuffer.c_str() << std::endl;
		closesocket(sock);
}

int atSB(CQmsg& msg){
	CQGroupMsg* group_msg = (CQGroupMsg*)&msg;
	CQJsonMsg jmsg_tmp;
	jmsg_tmp.append(at(group_msg->sender->id)).append(image("file:///F:/peXAlpha_Reborn/atsb.jpg"));
	sendGroupMsg(group_msg->group->id, jmsg_tmp.getJson());
	return 0;
}

int condition_atSB(CQmsg& msg){
	std::string str_tmp;
	if (!msg.content.isArray()) {
		return 0;
	}
	for (int i = 0; i < msg.content.size(); i++) {
		loadStringByKeyword("type", msg.content[i], str_tmp);
		if (str_tmp == "at") {
			if (msg.content[i].isMember("data")) {
				loadStringByKeyword("qq", msg.content[i]["data"], str_tmp);
				if (str_tmp == msg.self_id) {
					return 1;
				}
			}
		}
	}
	return 0;
}

void register_atSB(std::vector<CQEvent>& event_list){
	CQEvent event_tmp;
	event_tmp.event_func = atSB;
	event_tmp.event_type = EVENT_GROUP;
	event_tmp.custom_condition = condition_atSB;
	event_tmp.trig_type = TRIG_CUSTOMIZE;
	event_tmp.msg_codetype = CODE_UTF8;
	event_tmp.tag.index = 0;
	event_tmp.tag.name = "atsb";

	event_list.push_back(event_tmp);
}
