﻿#include <WinSock2.h>
#include <iostream>
#include <string>
#include <vector>
#include <windows.h>
#include <time.h>
#include <json/json.h>
#include "json_file.h"
#include "cq_connection.h"
#include "cq_api_post.h"
#include "cq_msg.h"
#include "cq_event.h"
#include "event_register.h"
#include "func_repeat.h"
#include "at_reply.h"
#include "alpha_inits.h"
#include "alpha_runtime.h"
#include "alpha_permissions.h"
#include "alpha_help.h"
#include "alpha_basic_event.h"

std::string RUN_PATH;

eventRegister events_reg;
CQGroupList groups_data;
CQGrpMbrDataList groups_members_data;
CQUserDataList users_data;
JsonFile_t bot_config_json;
alphaConfig bot_config;

void messageProcess(Json::Value& message);

void initialize();
void setEvents(eventRegister& event_reg);

int main() {
	std::string recv_str;

	Json::Reader json_reader;
	Json::Value recv_json;

	initialize();
	setEvents(events_reg);
	events_reg.registerEvents();

	SOCKET serv_sock;
	createConnection(serv_sock, bot_config.recv_host.c_str(), bot_config.recv_port);
	listen(serv_sock, 10000);

	std::string msg_temp;

	while (1) {
		recvJsonMessage(serv_sock, recv_str);
		//std::cout << recv_str << std::endl;

		if (json_reader.parse(recv_str, recv_json)) {
			loadStringByKeyword("post_type", recv_json, msg_temp);
			if (msg_temp == "message") {
				messageProcess(recv_json);
			}
		}

	}
	
	closeConnection(serv_sock);

	WSACleanup();
}

void messageProcess(Json::Value& message) {
	std::string str_temp;

	CQPrivateMsg private_msg;
	CQGroupMsg group_msg;
	CQmsg* ptr_general_msg;

	loadStringByKeyword("message_type", message, str_temp);
	if (str_temp == "private") {
		private_msg.load(message);
		loadCQmsgUserData(private_msg, users_data);
		ptr_general_msg = &private_msg;
	}
	else if (str_temp == "group") {
		group_msg.load(message);
		loadCQmsgUserData(group_msg, users_data);
		loadCQmsgGroupData(group_msg, groups_data, groups_members_data);

		std::cout << "[" << utf8ToGB2312(group_msg.sender->nickname) << "]在群 " << group_msg.group->id << " 发送了: ";
		std::cout << group_msg.uniText() << std::endl << std::endl;

		if (!isGroupAvailable(group_msg)) {
			checkGroupStart(group_msg);
			return;
		}
		ptr_general_msg = &group_msg;
	}
	else {
		return;
	}

	events_reg.executeEvents(*ptr_general_msg);
}

void initialize() {
	setlocale(LC_ALL, "chs");
	std::wcout.imbue(std::locale(""));
	WSADATA wsaData;
	WSAStartup(MAKEWORD(2, 2), &wsaData);

	RUN_PATH = getRunPath();
	//config init
	initConfig(RUN_PATH, bot_config_json, bot_config);
	cq_post_api::setPostIP(bot_config.post_host, bot_config.post_port);

	//permission init
	alpha_permission::setBotOwner(bot_config.owner_id);
	alpha_permission::setUserData(users_data);

	//data init
	initGroupsData(RUN_PATH + GROUP_DATA_PATH, groups_data, groups_members_data);
	alpha_runtime::setGroupDataFolder(RUN_PATH + GROUP_DATA_PATH);
	initUsersData(RUN_PATH + USER_DATA_PATH, users_data);
	alpha_runtime::setUserDataFolder(RUN_PATH + USER_DATA_PATH);

	//others
	alpha_help::setEventRegister(events_reg);
	alpha_help::setOwnerID(bot_config.owner_id);
}

void setEvents(eventRegister& event_reg) {
	event_reg.append(register_repeat);
	event_reg.append(register_setRepeatTimes);
	event_reg.append(register_atSB);
	event_reg.append(register_setOperator);
	event_reg.append(register_delOperator);
	event_reg.append(register_getHelp);
	event_reg.append(register_searchHelp);
	event_reg.append(register_enableGroup);
	event_reg.append(register_disableGroup);
	event_reg.append(register_dailySignIn);
}
